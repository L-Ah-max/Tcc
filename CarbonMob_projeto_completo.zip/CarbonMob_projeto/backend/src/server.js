const express = require("express");
const cors = require("cors");
const mysql = require("mysql2/promise");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const app = express();

app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "carbonmob",
  waitForConnections: true,
  connectionLimit: 10
});

const fatores = JSON.parse(
  fs.readFileSync(
    path.join(__dirname, "../../data/emission_factors.json"),
    "utf8"
  )
);

app.get("/", (req, res) => {
  res.json({
    sistema: "CarbonMob",
    status: "online"
  });
});

function calcularEmissao({ distancia, transporte, combustivel, consumo }) {
  if (transporte === "a_pe" || transporte === "bicicleta") {
    return {
      combustivel_gasto: 0,
      emissao_kg: 0,
      fator_emissao: 0
    };
  }

  if (!combustivel || !consumo || Number(consumo) <= 0) {
    throw new Error("Informe combustível e consumo do veículo.");
  }

  const fator = fatores.combustiveis[combustivel]?.fator_emissao;

  if (fator === null || fator === undefined) {
    throw new Error("O fator de emissão desse combustível ainda não foi configurado.");
  }

  const combustivelGasto = Number(distancia) / Number(consumo);
  const emissao = combustivelGasto * Number(fator);

  return {
    combustivel_gasto: Number(combustivelGasto.toFixed(3)),
    emissao_kg: Number(emissao.toFixed(3)),
    fator_emissao: Number(fator)
  };
}

app.post("/api/emissoes/calcular", (req, res) => {
  try {
    const { distancia, transporte, combustivel, consumo } = req.body;

    if (distancia === undefined || !transporte) {
      return res.status(400).json({
        erro: "Informe distância e transporte."
      });
    }

    const resultado = calcularEmissao({
      distancia,
      transporte,
      combustivel,
      consumo
    });

    res.json({
      distancia_km: Number(distancia),
      transporte,
      combustivel: combustivel || null,
      consumo_km_l: consumo || null,
      ...resultado
    });
  } catch (error) {
    res.status(400).json({ erro: error.message });
  }
});

app.post("/api/usuarios", async (req, res) => {
  const { nome, email, senha } = req.body;

  if (!nome || !email || !senha) {
    return res.status(400).json({ erro: "Preencha todos os campos." });
  }

  try {
    const [result] = await pool.query(
      "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)",
      [nome, email, senha]
    );

    res.status(201).json({
      id: result.insertId,
      nome,
      email
    });
  } catch (error) {
    res.status(400).json({
      erro: "Não foi possível cadastrar.",
      detalhe: error.message
    });
  }
});

app.post("/api/deslocamentos", async (req, res) => {
  try {
    const {
      usuario_id,
      origem,
      destino,
      distancia,
      tempo_minutos,
      transporte,
      combustivel,
      consumo
    } = req.body;

    const resultado = calcularEmissao({
      distancia,
      transporte,
      combustivel,
      consumo
    });

    const [insert] = await pool.query(
      `INSERT INTO deslocamentos
      (usuario_id, origem, destino, distancia_km, tempo_minutos,
       transporte, combustivel, consumo_km_l, combustivel_gasto_l, emissao_kg)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        usuario_id,
        origem,
        destino,
        distancia,
        tempo_minutos,
        transporte,
        combustivel || null,
        consumo || null,
        resultado.combustivel_gasto,
        resultado.emissao_kg
      ]
    );

    res.status(201).json({
      id: insert.insertId,
      ...resultado
    });
  } catch (error) {
    res.status(400).json({
      erro: error.message
    });
  }
});

app.get("/api/deslocamentos/:usuarioId", async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT * FROM deslocamentos
       WHERE usuario_id = ?
       ORDER BY data_deslocamento DESC`,
      [req.params.usuarioId]
    );

    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.get("/api/impacto/:usuarioId", async (req, res) => {
  try {
    const [total] = await pool.query(
      `SELECT
       COALESCE(SUM(emissao_kg), 0) AS total_emissao,
       COUNT(*) AS total_deslocamentos,
       COALESCE(AVG(emissao_kg), 0) AS media_emissao
       FROM deslocamentos
       WHERE usuario_id = ?`,
      [req.params.usuarioId]
    );

    const [mensal] = await pool.query(
      `SELECT
       DATE_FORMAT(data_deslocamento, '%Y-%m') AS mes,
       SUM(emissao_kg) AS emissao
       FROM deslocamentos
       WHERE usuario_id = ?
       GROUP BY DATE_FORMAT(data_deslocamento, '%Y-%m')
       ORDER BY mes`,
      [req.params.usuarioId]
    );

    res.json({
      resumo: total[0],
      mensal
    });
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.get("/api/creditos", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        c.id,
        p.nome AS projeto,
        p.empresa,
        p.tipo,
        p.descricao,
        c.preco,
        c.compensacao_kg,
        c.quantidade_disponivel
      FROM creditos_carbono c
      INNER JOIN projetos_ambientais p ON p.id = c.projeto_id
      ORDER BY c.preco ASC
    `);

    res.json(rows);
  } catch (error) {
    res.status(500).json({ erro: error.message });
  }
});

app.listen(process.env.PORT || 3000, () => {
  console.log(
    `CarbonMob API rodando em http://localhost:${process.env.PORT || 3000}`
  );
});
