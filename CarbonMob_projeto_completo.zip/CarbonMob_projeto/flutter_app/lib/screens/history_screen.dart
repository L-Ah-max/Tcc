import 'package:flutter/material.dart';
import '../services/api_service.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Histórico')),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.buscarHistorico(1),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('${snapshot.error}'));
          }

          final lista = snapshot.data ?? [];

          if (lista.isEmpty) {
            return const Center(
              child: Text('Nenhum deslocamento registrado.'),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(15),
            itemCount: lista.length,
            itemBuilder: (context, index) {
              final item = lista[index];

              return Card(
                child: ListTile(
                  title: Text(
                    '${item['origem']} → ${item['destino']}',
                  ),
                  subtitle: Text(
                    '${item['transporte']} • ${item['distancia_km']} km',
                  ),
                  trailing: Text(
                    '${item['emissao_kg']} kg',
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
