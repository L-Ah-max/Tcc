import 'package:flutter/material.dart';
import 'new_trip_screen.dart';
import 'history_screen.dart';
import 'impact_screen.dart';
import 'credits_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('CarbonMob'),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.person_outline),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, tamanho) {
          final colunas = tamanho.maxWidth >= 800 ? 4 : 2;

          return SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Bem-vindo ao CarbonMob',
                  style: TextStyle(
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Consulte seus deslocamentos e acompanhe suas emissões de CO₂.',
                ),
                const SizedBox(height: 25),
                GridView.count(
                  crossAxisCount: colunas,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 15,
                  mainAxisSpacing: 15,
                  children: [
                    _menu(
                      context,
                      'Novo deslocamento',
                      Icons.route,
                      const NewTripScreen(),
                    ),
                    _menu(
                      context,
                      'Histórico',
                      Icons.history,
                      const HistoryScreen(),
                    ),
                    _menu(
                      context,
                      'Meu impacto',
                      Icons.co2,
                      const ImpactScreen(),
                    ),
                    _menu(
                      context,
                      'Créditos de carbono',
                      Icons.eco,
                      const CreditsScreen(),
                    ),
                  ],
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _menu(
    BuildContext context,
    String titulo,
    IconData icone,
    Widget tela,
  ) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => tela),
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icone, size: 45, color: Colors.green),
            const SizedBox(height: 10),
            Text(
              titulo,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
