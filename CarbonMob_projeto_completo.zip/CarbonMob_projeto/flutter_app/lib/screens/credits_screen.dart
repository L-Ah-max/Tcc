import 'package:flutter/material.dart';
import '../services/api_service.dart';

class CreditsScreen extends StatefulWidget {
  const CreditsScreen({super.key});

  @override
  State<CreditsScreen> createState() => _CreditsScreenState();
}

class _CreditsScreenState extends State<CreditsScreen> {
  String busca = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Créditos de carbono')),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.buscarCreditos(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('${snapshot.error}'));
          }

          final lista = snapshot.data ?? [];

          final filtrados = lista.where((item) {
            final texto =
                '${item['projeto']} ${item['empresa']} ${item['tipo']}'
                    .toLowerCase();

            return texto.contains(busca.toLowerCase());
          }).toList();

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(15),
                child: TextField(
                  decoration: const InputDecoration(
                    labelText: 'Pesquisar crédito',
                    prefixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (valor) {
                    setState(() => busca = valor);
                  },
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: filtrados.length,
                  itemBuilder: (context, index) {
                    final item = filtrados[index];

                    return Card(
                      margin: const EdgeInsets.symmetric(
                        horizontal: 15,
                        vertical: 7,
                      ),
                      child: ListTile(
                        title: Text(item['projeto']),
                        subtitle: Text(
                          '${item['tipo']}
'
                          '${item['compensacao_kg']} kg de CO₂
'
                          'R\$ ${item['preco']}',
                        ),
                        isThreeLine: true,
                        trailing: FilledButton(
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                  'Compra preparada para integração.',
                                ),
                              ),
                            );
                          },
                          child: const Text('Comprar'),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
