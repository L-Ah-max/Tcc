import 'package:flutter/material.dart';
import '../services/api_service.dart';

class ComparisonScreen extends StatefulWidget {
  final double distancia;

  const ComparisonScreen({
    super.key,
    required this.distancia,
  });

  @override
  State<ComparisonScreen> createState() => _ComparisonScreenState();
}

class _ComparisonScreenState extends State<ComparisonScreen> {
  final transportes = const [
    ['a_pe', 'A pé'],
    ['bicicleta', 'Bicicleta'],
  ];

  final resultados = <String, String>{};

  @override
  void initState() {
    super.initState();
    carregar();
  }

  Future<void> carregar() async {
    for (final item in transportes) {
      try {
        final resultado = await ApiService.calcularEmissao(
          distancia: widget.distancia,
          transporte: item[0],
        );

        resultados[item[0]] =
            '${resultado['emissao_kg']} kg de CO₂';
      } catch (_) {
        resultados[item[0]] = 'Não disponível';
      }
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Comparação')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Compare as opções disponíveis para a mesma distância.',
            style: TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 15),
          ...transportes.map(
            (item) => Card(
              child: ListTile(
                title: Text(item[1]),
                subtitle: Text(
                  resultados[item[0]] ?? 'Calculando...',
                ),
              ),
            ),
          ),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(15),
              child: Text(
                'O CarbonMob apresenta as informações para auxiliar sua decisão. O aplicativo não escolhe o transporte pelo usuário.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
