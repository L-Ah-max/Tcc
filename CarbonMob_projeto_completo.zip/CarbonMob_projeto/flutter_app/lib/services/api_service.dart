import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = 'http://localhost:3000/api';

  static Future<Map<String, dynamic>> calcularEmissao({
    required double distancia,
    required String transporte,
    String? combustivel,
    double? consumo,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/emissoes/calcular'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'distancia': distancia,
        'transporte': transporte,
        'combustivel': combustivel,
        'consumo': consumo,
      }),
    );

    final body = jsonDecode(response.body);

    if (response.statusCode != 200) {
      throw Exception(body['erro']);
    }

    return body;
  }

  static Future<void> cadastrarUsuario(
    String nome,
    String email,
    String senha,
  ) async {
    final response = await http.post(
      Uri.parse('$baseUrl/usuarios'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'nome': nome,
        'email': email,
        'senha': senha,
      }),
    );

    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['erro']);
    }
  }

  static Future<void> salvarDeslocamento(Map<String, dynamic> dados) async {
    final response = await http.post(
      Uri.parse('$baseUrl/deslocamentos'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(dados),
    );

    if (response.statusCode != 201) {
      final body = jsonDecode(response.body);
      throw Exception(body['erro']);
    }
  }

  static Future<List<dynamic>> buscarHistorico(int usuarioId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/deslocamentos/$usuarioId'),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao buscar histórico.');
    }

    return jsonDecode(response.body);
  }

  static Future<Map<String, dynamic>> buscarImpacto(int usuarioId) async {
    final response = await http.get(
      Uri.parse('$baseUrl/impacto/$usuarioId'),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao buscar impacto.');
    }

    return jsonDecode(response.body);
  }

  static Future<List<dynamic>> buscarCreditos() async {
    final response = await http.get(
      Uri.parse('$baseUrl/creditos'),
    );

    if (response.statusCode != 200) {
      throw Exception('Erro ao buscar créditos.');
    }

    return jsonDecode(response.body);
  }
}
